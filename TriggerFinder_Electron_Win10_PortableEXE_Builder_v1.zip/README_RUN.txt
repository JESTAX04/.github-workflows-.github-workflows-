Run (recommended):
1) Open folder in VS Code
2) Install "Live Server" extension
3) Right click public/index.html -> Open with Live Server
Do NOT open via file:// (double click) or Firebase config errors / missing assets will happen.

Flow:
- Login page: public/index.html
- After login redirects to public/dashboard.html
- TriggerFinder: public/triggerfinder.html
