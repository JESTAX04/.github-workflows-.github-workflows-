window.APP_CONFIG = {
 discord: {
 clientId: "1468822461888987200",
 redirectUri: window.location.origin + window.location.pathname,
 scope: "identify email"
 },

 firebase: {
 apiKey: "AIzaSyAGUMoOvEKwwsdNnT2Fqu3KZUgnHX8OK-k",
 authDomain: "h46h-6714c.firebaseapp.com",
 projectId: "h46h-6714c",
 storageBucket: "h46h-6714c.firebasestorage.app",
 messagingSenderId: "45140235959",
 appId: "1:45140235959:web:6b0b5c08949bb2a1ccdf32"
 },

 logs: { discordWebhookUrl: "" },

 roles: { owners: ["1102216273187840082"], admins: [] },
uiAccess: {
 // Admin-only button labels (case-insensitive)
 adminOnlyButtons: ["WEBHOOKS","EXPORT","CFX"],
 // Owner-only button labels
 ownerOnlyButtons: []
 },
};
