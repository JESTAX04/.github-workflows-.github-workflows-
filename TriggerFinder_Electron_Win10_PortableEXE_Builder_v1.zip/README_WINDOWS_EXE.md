# TriggerFinder Desktop (Windows 10 x64) – No-Command EXE Builder

## 1) Build the Portable EXE (double-click)
1. Unzip this folder
2. Double-click: **build-exe.bat**
3. When it finishes, go to **dist/** and run the generated **.exe**

✅ You do NOT need to type npm commands manually.  
⚠️ Internet is required the first time (downloads Node + dependencies).

## 2) Run the app (after build)
- Run the EXE in **dist/**

## Troubleshooting
- If Windows blocks the script, click **More info → Run anyway**.
- If PowerShell execution is blocked, right click **build-exe.bat → Run as administrator**.
